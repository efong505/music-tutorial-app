# Music Tutorial Frontend (Mock)

A ready-to-run Angular **standalone** app with a **mock backend** so you can test UI without AWS.

## Quickstart
```bash
npm install
npm start  # http://localhost:4200
```

- Home lists demo courses (mock data)
- Admin page lets you create a course (in-memory)
- Login uses a mocked user/token
- Interceptor attaches a mock JWT to requests

## Switch to AWS later
- Set `mock: false` in `src/environments/environment.ts`
- Replace AuthService and CourseService logic with real API calls (as in the full tutorial)
