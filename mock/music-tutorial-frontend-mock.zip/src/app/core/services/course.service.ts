import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

export interface Course {
  courseId: string;
  title: string;
  description: string;
  priceCents: number;
  enrolled?: boolean;
}

@Injectable({ providedIn: 'root' })
export class CourseService {
  private courses: Course[] = [
    { courseId: 'c_rock', title: 'Rock Guitar Basics', description: 'Power chords, riffs, rhythm.', priceCents: 1999 },
    { courseId: 'c_jazz', title: 'Jazz Improvisation', description: 'Modes, ii-V-I progressions.', priceCents: 2999 },
    { courseId: 'c_piano', title: 'Piano Fundamentals', description: 'Scales, arpeggios, reading.', priceCents: 1499 }
  ];

  getCourses(): Observable<Course[]> {
    // Mark rock course as enrolled for demo
    const enriched = this.courses.map(c => c.courseId === 'c_rock' ? { ...c, enrolled: true } : c);
    return of(enriched);
  }

  createCourse(title: string, description: string, priceCents: number): Observable<Course> {
    const newCourse: Course = {
      courseId: 'c_' + Math.random().toString(36).slice(2, 8),
      title, description, priceCents
    };
    this.courses = [newCourse, ...this.courses];
    return of(newCourse);
  }
}
