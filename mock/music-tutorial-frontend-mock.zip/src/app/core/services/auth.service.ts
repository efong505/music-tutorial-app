import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';

export interface User { userId: string; email: string; name: string; role: 'student' | 'admin'; token?: string; }

@Injectable({ providedIn: 'root' })
export class AuthService {
  private _user = new BehaviorSubject<User | null>(null);
  user$ = this._user.asObservable();

  get token() { return this._user.value?.token || ''; }

  // MOCK AUTH — toggled by environment.mock in a real app; here always enabled
  mockLogin(role: 'student' | 'admin' = 'admin') {
    const fake: User = {
      userId: 'u_123',
      email: 'demo@example.com',
      name: role === 'admin' ? 'Admin Demo' : 'Student Demo',
      role,
      token: 'mock-jwt-token'
    };
    this._user.next(fake);
  }

  logout(){ this._user.next(null); }

  isLoggedIn(): boolean { return !!this._user.value; }
  isAdmin(): boolean { return this._user.value?.role === 'admin'; }
}
