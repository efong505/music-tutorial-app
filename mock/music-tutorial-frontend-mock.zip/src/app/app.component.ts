import { Component } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';
import { AsyncPipe, NgIf } from '@angular/common';
import { AuthService } from './core/services/auth.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink, AsyncPipe, NgIf],
  template: `
  <div class="container">
    <div class="toolbar card">
      <div><strong>Music Tutorial App (Mock)</strong></div>
      <div *ngIf="(auth.user$ | async) as user; else loggedOut">
        <span>Hi, {{user.name}}!</span>
        <button (click)="logout()">Logout</button>
      </div>
      <ng-template #loggedOut>
        <button class="primary" (click)="login()">Login</button>
      </ng-template>
    </div>
    <router-outlet></router-outlet>
  </div>
  `
})
export class AppComponent {
  constructor(public auth: AuthService) {}
  login(){ this.auth.mockLogin(); }
  logout(){ this.auth.logout(); }
}
