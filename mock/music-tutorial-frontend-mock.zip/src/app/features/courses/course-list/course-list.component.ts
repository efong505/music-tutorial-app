import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CourseService, Course } from '../../../core/services/course.service';

@Component({
  standalone: true,
  selector: 'app-course-list',
  imports: [CommonModule],
  template: `
  <div class="card">
    <h2>Courses</h2>
    <table>
      <thead><tr><th>Title</th><th>Description</th><th>Price</th><th>Status</th></tr></thead>
      <tbody>
        <tr *ngFor="let c of courses">
          <td>{{c.title}}</td>
          <td>{{c.description}}</td>
          <td>\${{(c.priceCents/100) | number:'1.2-2'}}</td>
          <td>{{c.enrolled ? 'Enrolled' : 'Not enrolled'}}</td>
        </tr>
      </tbody>
    </table>
  </div>
  `
})
export class CourseListComponent implements OnInit {
  courses: Course[] = [];
  constructor(private courseSvc: CourseService) {}
  ngOnInit(){ this.courseSvc.getCourses().subscribe(cs => this.courses = cs); }
}
