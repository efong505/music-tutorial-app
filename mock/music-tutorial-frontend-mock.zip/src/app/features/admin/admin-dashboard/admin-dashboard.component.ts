import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CourseService } from '../../../core/services/course.service';

@Component({
  standalone: true,
  selector: 'app-admin-dashboard',
  imports: [CommonModule, FormsModule],
  template: `
  <div class="card">
    <h2>Admin Dashboard</h2>
    <form (ngSubmit)="create()">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem">
        <label>Title <input [(ngModel)]="title" name="title"></label>
        <label>Price (USD) <input type="number" [(ngModel)]="price" name="price"></label>
      </div>
      <label>Description <input [(ngModel)]="description" name="description" style="width:100%"></label>
      <div style="margin-top:1rem">
        <button class="primary" type="submit">Create Course</button>
      </div>
    </form>
    <div *ngIf="createdId" style="margin-top:1rem">Created course id: <strong>{{createdId}}</strong></div>
  </div>
  `
})
export class AdminDashboardComponent {
  title = ''; description = ''; price = 19.99; createdId = '';
  constructor(private courses: CourseService) {}
  create(){
    const cents = Math.round(this.price * 100);
    this.courses.createCourse(this.title, this.description, cents).subscribe(c => this.createdId = c.courseId);
  }
}
