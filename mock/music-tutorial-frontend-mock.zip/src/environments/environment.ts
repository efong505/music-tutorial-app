export const environment = {
  production: false,
  mock: true,
  apiUrl: 'http://localhost:3000', // ignored in mock mode
  cognitoUserPoolId: '',
  cognitoClientId: '',
  stripePublicKey: ''
};
